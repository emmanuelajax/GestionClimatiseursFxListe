package sio.d3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class PrimaryController
{
    static List<Climatiseur> Clims = new ArrayList<Climatiseur>();

    @FXML
    private Label marque;
    @FXML
    private Label puissance;




    @FXML
    public void initialize()
    {
        marque.setText("Saisir la marque : ");
        marque.getText();

        puissance.setText("Saisir la puissance");
        puissance.getText();
    }
    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
        int p = 7000;
        String m = marque.getAccessibleText();

        Climatiseur climatiseur = new Climatiseur(p ,m);
        Clims.add(climatiseur);
        App.AfficheClimatiseur();
    }
    /*@FXML
    public static void AfficheClimatiseur()
    {

    }*/


}
