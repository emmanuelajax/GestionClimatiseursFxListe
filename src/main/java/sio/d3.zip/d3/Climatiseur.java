package sio.d3;

public class Climatiseur {
    private java.lang.String marque;
    private int puissance;
    private int surfaceMax;
    private int surfaceMin;


    public void setMarque(String marque)
    {
        this.marque = marque;
    }

    public void setPuissance (int puissance)
    {
        this.puissance = puissance;
    }

    public int getPuissance()
    {
        return puissance;
    }

    public String getMarque()
    {
        return marque;
    }

    public int getSurfaceMax()
    {
        return surfaceMax;
    }

    public void setSurfaceMax(int surfaceMax)
    {
        this.surfaceMax = surfaceMax;
    }

    public int getSurfaceMin()
    {
        return surfaceMin;
    }

    public void setSurfaceMin(int surfaceMin)
    {
        this.surfaceMin = surfaceMin;
    }

    public Climatiseur (int p,String m)
    {
        this.puissance = p;
        this.marque = m;
        switch (puissance) {
            case 7000:
                this.surfaceMin = 7;
                this.surfaceMax = 15;
                break;

            case 9000:
                this.surfaceMin = 15;
                this.surfaceMax = 25;
                break;

            case 12000:
                this.surfaceMin = 25;
                this.surfaceMax = 35;
                break;

            case 18000:
                this.surfaceMin = 35;
                this.surfaceMax = 50;
                break;

            case 24000:
                this.surfaceMin = 50;
                this.surfaceMax = 70;
                break;

            case 30000:
                this.surfaceMin = 70;
                this.surfaceMax = 80;
                break;

        }
    }
}
